void quicksort(int *A, int len) {
    if (len < 2) return;
   
    int pivot = A[len / 2];
   
    int i, j;
    for (i = 0, j = len - 1; ; i++, j--) {
      while (A[i] < pivot) i++;
      while (A[j] > pivot) j--;
   
      if (i >= j) break;
   
      int temp = A[i];
      A[i]     = A[j];
      A[j]     = temp;
    }
    quicksort(A, i);
    quicksort(A + i, len - i);
}