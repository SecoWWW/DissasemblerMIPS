int supper(char a, char b, char c, char d, char e){
    int sum;
    sum += a + b * (a + c) - d * e + e - a / c + b;
}