int sum(char c, int a[]) {
	int sum=0;
	char i;
	for (i=0; i<c; i++) sum+=a[i];
	return sum;
}
