int sum(int a, int b){
    return a + b;
}

int main(){
    int a,b,c;
    a = 4;
    b = 5;
    c = sum(a,b);
}